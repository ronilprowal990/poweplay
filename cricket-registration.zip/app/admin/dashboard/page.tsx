"use client"
import { useEffect, useState, useCallback } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Search, LogOut, Download, RefreshCw, Plus, Trash2, Bell, Eye, Edit, Save } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Textarea } from "@/components/ui/textarea"
import {
  subscribeToEvents,
  updateRegistrationStatus,
  getRegistrationStatus,
  getHomeContent,
  updateHomeContent,
  getRegistrations,
  deleteRegistration,
} from "@/lib/sync-service"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Form field configuration
const initialFormFields = [
  { id: "name", label: "Full Name", type: "text", required: true, enabled: true },
  { id: "fatherName", label: "Father's Name", type: "text", required: true, enabled: true },
  { id: "age", label: "Age", type: "number", required: true, enabled: true },
  { id: "email", label: "Email", type: "email", required: true, enabled: true },
  { id: "phone", label: "Phone Number", type: "tel", required: true, enabled: true },
  { id: "city", label: "City", type: "text", required: true, enabled: true },
  { id: "jerseySize", label: "Jersey Size", type: "select", required: true, enabled: true },
  { id: "playerRole", label: "Player Role", type: "select", required: true, enabled: true },
  { id: "battingStyle", label: "Batting Style", type: "radio", required: true, enabled: true },
  { id: "bowlingStyle", label: "Bowling Style", type: "radio", required: true, enabled: true },
  { id: "profilePhoto", label: "Profile Photo", type: "file", required: false, enabled: true },
]

export default function AdminDashboard() {
  const [registrations, setRegistrations] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [formFields, setFormFields] = useState(initialFormFields)
  const [newField, setNewField] = useState({ id: "", label: "", type: "text", required: false, enabled: true })
  const [selectedColumns, setSelectedColumns] = useState(formFields.map((field) => field.id))
  const [liveUpdatesEnabled, setLiveUpdatesEnabled] = useState(true)
  const [newRegistrationAlert, setNewRegistrationAlert] = useState(false)
  const [newRegistrations, setNewRegistrations] = useState([])
  const [selectedRegistration, setSelectedRegistration] = useState(null)
  const [showRegistrationDetails, setShowRegistrationDetails] = useState(false)
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(true)
  const [statusNotification, setStatusNotification] = useState(null)
  const [homeContent, setHomeContent] = useState({
    title: "PowerPlay Champions Trophy",
    subtitle: "Join the most exciting cricket tournament of the year! Register now to showcase your talent.",
    announcement: "",
  })
  const [isEditingHomeContent, setIsEditingHomeContent] = useState(false)
  const [syncStatus, setSyncStatus] = useState({ status: "connected", lastSync: Date.now() })

  // Load data function - extracted for reuse
  const loadData = useCallback(async () => {
    try {
      // Load registrations
      const loadedRegistrations = getRegistrations()
      setRegistrations(loadedRegistrations)

      // Load registration status
      setIsRegistrationOpen(getRegistrationStatus())

      // Load home content
      setHomeContent(getHomeContent())

      setSyncStatus({ status: "connected", lastSync: Date.now() })
    } catch (error) {
      console.error("Error loading data:", error)
      setSyncStatus({ status: "error", lastSync: Date.now() })
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    // Initial data load
    loadData()

    // Subscribe to real-time updates with a faster polling interval for admin panel
    const unsubscribe = subscribeToEvents((events) => {
      if (!liveUpdatesEnabled) return

      let shouldReloadData = false
      const newRegs = []

      events.forEach((event) => {
        console.log("Received event:", event.type, event.data)

        if (event.type === "REGISTRATION_STATUS_CHANGE") {
          setIsRegistrationOpen(event.data.isOpen)

          // Show notification
          setStatusNotification({
            message: `Registration ${event.data.isOpen ? "opened" : "closed"} by another admin`,
            type: event.data.isOpen ? "success" : "info",
          })

          // Auto-hide notification after 3 seconds
          setTimeout(() => {
            setStatusNotification(null)
          }, 3000)
        } else if (event.type === "NEW_REGISTRATION") {
          // Add to new registrations list
          newRegs.push(event.data)
          shouldReloadData = true

          // Immediate update to registrations list for faster sync
          setRegistrations((prev) => {
            // Check if this registration is already in the list
            if (!prev.some((reg) => reg.id === event.data.id)) {
              return [...prev, event.data]
            }
            return prev
          })
        } else if (event.type === "HOME_CONTENT_UPDATE") {
          // Force a re-render by creating a new object
          setHomeContent({ ...event.data })
          console.log("Updated home content in admin panel:", event.data)

          // Show notification if not editing
          if (!isEditingHomeContent) {
            setStatusNotification({
              message: "Home content updated by another admin",
              type: "info",
            })

            // Auto-hide notification after 3 seconds
            setTimeout(() => {
              setStatusNotification(null)
            }, 3000)
          }
        } else if (event.type === "ADMIN_ACTION") {
          if (event.data.action === "DELETE_REGISTRATION") {
            // Immediately update local registration list instead of waiting for reload
            setRegistrations((prev) => prev.filter((reg) => reg.id !== event.data.id))

            // If deleted registration is currently selected, close the details dialog
            if (selectedRegistration && selectedRegistration.id === event.data.id) {
              setShowRegistrationDetails(false)
            }
          }
          shouldReloadData = true
        }
      })

      // Handle new registrations if any
      if (newRegs.length > 0) {
        setNewRegistrations((prev) => [...prev, ...newRegs])
        setNewRegistrationAlert(true)

        // Play notification sound
        try {
          const audio = new Audio("/notification-sound.mp3")
          audio.volume = 0.5
          audio.play().catch((err) => console.log("Audio playback prevented:", err))
        } catch (err) {
          console.log("Audio playback error:", err)
        }

        // Auto-hide after 10 seconds
        setTimeout(() => {
          setNewRegistrationAlert(false)
          setNewRegistrations([])
        }, 10000)
      }

      // Update sync status
      setSyncStatus({ status: "connected", lastSync: Date.now() })
    }, 200) // Poll every 200ms for more responsive updates

    return () => unsubscribe()
  }, [loadData, liveUpdatesEnabled, isEditingHomeContent, selectedRegistration])

  const filteredRegistrations = registrations.filter(
    (reg) =>
      reg.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reg.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reg.phone?.includes(searchTerm) ||
      reg.city?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleExportCSV = () => {
    // Create CSV content
    const headers = formFields
      .filter((field) => field.enabled && selectedColumns.includes(field.id))
      .map((field) => field.label)

    const csvRows = [
      headers.join(","),
      ...filteredRegistrations.map((reg) =>
        formFields
          .filter((field) => field.enabled && selectedColumns.includes(field.id))
          .map((field) => reg[field.id] || "")
          .join(","),
      ),
    ]

    const csvContent = csvRows.join("\n")

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", "cricket_registrations.csv")
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleAddField = () => {
    if (newField.id && newField.label) {
      setFormFields([...formFields, { ...newField }])
      setNewField({ id: "", label: "", type: "text", required: false, enabled: true })
    }
  }

  const handleRemoveField = (fieldId) => {
    setFormFields(formFields.filter((field) => field.id !== fieldId))
  }

  const handleToggleField = (fieldId) => {
    setFormFields(formFields.map((field) => (field.id === fieldId ? { ...field, enabled: !field.enabled } : field)))
  }

  const handleToggleRequired = (fieldId) => {
    setFormFields(formFields.map((field) => (field.id === fieldId ? { ...field, required: !field.required } : field)))
  }

  const handleToggleColumn = (columnId) => {
    if (selectedColumns.includes(columnId)) {
      setSelectedColumns(selectedColumns.filter((id) => id !== columnId))
    } else {
      setSelectedColumns([...selectedColumns, columnId])
    }
  }

  const handleDeleteRegistration = (id) => {
    deleteRegistration(id)
    setRegistrations(registrations.filter((reg) => reg.id !== id))

    // If the deleted registration is currently selected, close the details dialog
    if (selectedRegistration && selectedRegistration.id === id) {
      setShowRegistrationDetails(false)
    }
  }

  const handleViewRegistration = (registration) => {
    setSelectedRegistration(registration)
    setShowRegistrationDetails(true)
  }

  const formatDate = (dateString) => {
    const options = {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  const handleToggleRegistration = () => {
    const newStatus = !isRegistrationOpen
    setIsRegistrationOpen(newStatus)

    // Update registration status using sync service
    updateRegistrationStatus(newStatus)

    // Show notification
    setStatusNotification({
      message: `Registration ${newStatus ? "opened" : "closed"} successfully`,
      type: newStatus ? "success" : "info",
    })

    // Hide notification after 3 seconds
    setTimeout(() => {
      setStatusNotification(null)
    }, 3000)
  }

  const handleSaveHomeContent = () => {
    // Create a copy of the content to avoid reference issues
    const contentToUpdate = { ...homeContent }

    // Update home content using sync service
    const success = updateHomeContent(contentToUpdate)

    if (success) {
      console.log("Home content updated successfully")
      setIsEditingHomeContent(false)

      // Show notification
      setStatusNotification({
        message: "Home content updated successfully",
        type: "success",
      })

      // Hide notification after 3 seconds
      setTimeout(() => {
        setStatusNotification(null)
      }, 3000)
    } else {
      // Show error notification
      setStatusNotification({
        message: "Failed to update home content. Please try again.",
        type: "error",
      })

      // Hide notification after 3 seconds
      setTimeout(() => {
        setStatusNotification(null)
      }, 3000)
    }
  }

  // Format the last sync time
  const formatSyncTime = (timestamp) => {
    const now = Date.now()
    const diff = now - timestamp

    if (diff < 60000) {
      // Less than a minute
      return "Just now"
    } else if (diff < 3600000) {
      // Less than an hour
      return `${Math.floor(diff / 60000)} min ago`
    } else {
      return formatDate(timestamp)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#002147] border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <div className="relative w-10 h-10 mr-3">
              <Image
                src="/images/powerplay-logo.png"
                alt="PowerPlay Champions Trophy"
                fill
                className="object-contain"
              />
            </div>
            <h1 className="text-xl font-bold text-[#F5E6CA]">PowerPlay Admin</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center mr-4">
              <Label htmlFor="registration-toggle" className="mr-2 text-[#F5E6CA] text-sm">
                {isRegistrationOpen ? "Registration Open" : "Registration Closed"}
              </Label>
              <Switch
                id="registration-toggle"
                checked={isRegistrationOpen}
                onCheckedChange={handleToggleRegistration}
                className={isRegistrationOpen ? "bg-green-500" : "bg-red-500"}
              />
            </div>
            {newRegistrationAlert && (
              <div className="relative">
                <button
                  onClick={() => setNewRegistrationAlert(false)}
                  className="animate-pulse flex items-center bg-green-500 text-white px-4 py-2 rounded-full text-sm font-medium"
                >
                  <Bell className="h-4 w-4 mr-2" />
                  {newRegistrations.length} new registration{newRegistrations.length > 1 ? "s" : ""}!
                </button>
                <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-lg shadow-xl z-50 overflow-hidden">
                  {newRegistrations.map((reg) => (
                    <div key={reg.id} className="p-3 border-b hover:bg-gray-50">
                      <div className="flex items-center">
                        <div className="mr-3">
                          <Avatar>
                            <AvatarImage src={reg.profilePhotoUrl || "/placeholder.svg"} alt={reg.name} />
                            <AvatarFallback>{reg.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        </div>
                        <div>
                          <p className="font-medium text-sm">{reg.name}</p>
                          <p className="text-xs text-gray-500">
                            {reg.playerRole} • {reg.city}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="ml-auto"
                          onClick={() => handleViewRegistration(reg)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center">
              <Label htmlFor="live-updates" className="mr-2 text-[#F5E6CA] text-sm">
                Live Updates
              </Label>
              <Switch id="live-updates" checked={liveUpdatesEnabled} onCheckedChange={setLiveUpdatesEnabled} />
            </div>
            <Link href="/admin">
              <Button
                variant="outline"
                size="sm"
                className="bg-transparent text-[#F5E6CA] border-[#F5E6CA] hover:bg-[#F5E6CA] hover:text-[#002147]"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Sync Status Indicator */}
      <div className="bg-gray-100 border-b px-4 py-1 flex justify-between items-center text-xs text-gray-500">
        <div className="flex items-center">
          <div
            className={`w-2 h-2 rounded-full mr-2 ${syncStatus.status === "connected" ? "bg-green-500" : "bg-red-500"}`}
          ></div>
          <span>{syncStatus.status === "connected" ? "Real-time sync active" : "Sync error"}</span>
        </div>
        <div>Last updated: {formatSyncTime(syncStatus.lastSync)}</div>
      </div>

      {statusNotification && (
        <div
          className={`fixed top-20 right-4 z-50 p-4 rounded-md shadow-lg ${
            statusNotification.type === "success"
              ? "bg-green-100 border border-green-200"
              : statusNotification.type === "info"
                ? "bg-blue-100 border border-blue-200"
                : "bg-yellow-100 border border-yellow-200"
          }`}
        >
          <div className="flex items-center">
            <div
              className={`mr-3 ${
                statusNotification.type === "success"
                  ? "text-green-500"
                  : statusNotification.type === "info"
                    ? "text-blue-500"
                    : "text-yellow-500"
              }`}
            >
              {statusNotification.type === "success" ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                  <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
              ) : statusNotification.type === "info" ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="16" x2="12" y2="12"></line>
                  <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                  <line x1="12" y1="9" x2="12" y2="13"></line>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
              )}
            </div>
            <p
              className={`text-sm font-medium ${
                statusNotification.type === "success"
                  ? "text-green-800"
                  : statusNotification.type === "info"
                    ? "text-blue-800"
                    : "text-yellow-800"
              }`}
            >
              {statusNotification.message}
            </p>
          </div>
        </div>
      )}

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="registrations">
          <TabsList className="mb-6">
            <TabsTrigger value="registrations">Registrations</TabsTrigger>
            <TabsTrigger value="form-fields">Form Fields</TabsTrigger>
            <TabsTrigger value="home-content">Home Content</TabsTrigger>
          </TabsList>

          <TabsContent value="registrations">
            <Card>
              <CardHeader className="bg-gray-50">
                <div className="flex items-center">
                  <div className="relative w-12 h-12 mr-4">
                    <Image
                      src="/images/powerplay-logo.png"
                      alt="PowerPlay Champions Trophy"
                      fill
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <CardTitle className="text-[#002147]">Player Registrations</CardTitle>
                    <div className="flex items-center mt-2">
                      <div
                        className={`w-3 h-3 rounded-full mr-2 ${isRegistrationOpen ? "bg-green-500" : "bg-red-500"}`}
                      ></div>
                      <CardDescription>
                        Registration status:{" "}
                        <span
                          className={isRegistrationOpen ? "text-green-600 font-medium" : "text-red-600 font-medium"}
                        >
                          {isRegistrationOpen ? "Open" : "Closed"}
                        </span>
                      </CardDescription>
                    </div>
                    <CardDescription>Manage all player registrations for PowerPlay Champions Trophy</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                  <div className="relative w-full md:w-auto flex-1 max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by name, email, phone or city..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  <div className="flex items-center gap-2 w-full md:w-auto">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          Columns
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Manage Columns</DialogTitle>
                          <DialogDescription>Select which columns to display in the table</DialogDescription>
                        </DialogHeader>
                        <div className="grid grid-cols-2 gap-4 py-4">
                          {formFields
                            .filter((field) => field.enabled)
                            .map((field) => (
                              <div key={field.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`column-${field.id}`}
                                  checked={selectedColumns.includes(field.id)}
                                  onCheckedChange={() => handleToggleColumn(field.id)}
                                />
                                <label
                                  htmlFor={`column-${field.id}`}
                                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                >
                                  {field.label}
                                </label>
                              </div>
                            ))}
                        </div>
                        <DialogFooter>
                          <Button
                            onClick={() => setSelectedColumns(formFields.filter((f) => f.enabled).map((f) => f.id))}
                            variant="outline"
                          >
                            Select All
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    <Button variant="outline" size="sm" onClick={loadData}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh
                    </Button>
                    <Button
                      size="sm"
                      className="bg-[#F2B705] hover:bg-[#e6a800] text-[#002147]"
                      onClick={handleExportCSV}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export CSV
                    </Button>
                  </div>
                </div>

                {isLoading ? (
                  <div className="py-20 text-center">
                    <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#F2B705] border-r-transparent"></div>
                    <p className="mt-4 text-muted-foreground">Loading registrations...</p>
                  </div>
                ) : filteredRegistrations.length === 0 ? (
                  <div className="py-20 text-center">
                    <p className="text-muted-foreground">No registrations found</p>
                  </div>
                ) : (
                  <div className="rounded-md border overflow-hidden overflow-x-auto">
                    <Table>
                      <TableHeader className="bg-[#002147]/5">
                        <TableRow>
                          <TableHead className="w-[50px]">Actions</TableHead>
                          <TableHead className="w-[60px]">Photo</TableHead>
                          {formFields
                            .filter(
                              (field) =>
                                field.enabled && selectedColumns.includes(field.id) && field.id !== "profilePhoto",
                            )
                            .map((field) => (
                              <TableHead key={field.id}>{field.label}</TableHead>
                            ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredRegistrations.map((reg) => (
                          <TableRow key={reg.id} className="group">
                            <TableCell>
                              <div className="flex space-x-1">
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-8 w-8 text-blue-500"
                                        onClick={() => handleViewRegistration(reg)}
                                      >
                                        <Eye className="h-4 w-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>View Details</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>

                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-8 w-8 text-red-500"
                                        onClick={() => handleDeleteRegistration(reg.id)}
                                      >
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Delete</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Avatar className="h-10 w-10 border-2 border-[#F2B705] group-hover:scale-110 transition-transform">
                                <AvatarImage src={reg.profilePhotoUrl || "/placeholder.svg"} alt={reg.name} />
                                <AvatarFallback className="bg-[#002147] text-white">
                                  {reg.name?.charAt(0)}
                                </AvatarFallback>
                              </Avatar>
                            </TableCell>
                            {formFields
                              .filter(
                                (field) =>
                                  field.enabled && selectedColumns.includes(field.id) && field.id !== "profilePhoto",
                              )
                              .map((field) => (
                                <TableCell key={field.id}>
                                  {field.id === "playerRole" ? (
                                    <span className="inline-flex items-center">
                                      {reg.playerRole === "Batsman" && "🏏 "}
                                      {reg.playerRole === "Bowler" && "🎯 "}
                                      {reg.playerRole === "All-Rounder" && "⭐ "}
                                      {reg.playerRole === "Wicket Keeper" && "🧤 "}
                                      {reg.playerRole}
                                    </span>
                                  ) : field.id === "timestamp" ? (
                                    formatDate(reg.timestamp)
                                  ) : (
                                    reg[field.id]
                                  )}
                                </TableCell>
                              ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="form-fields">
            <Card>
              <CardHeader>
                <CardTitle>Manage Form Fields</CardTitle>
                <CardDescription>Add, remove, or modify fields in the registration form</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex flex-col space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="field-id">Field ID</Label>
                        <Input
                          id="field-id"
                          value={newField.id}
                          onChange={(e) => setNewField({ ...newField, id: e.target.value })}
                          placeholder="e.g. phoneNumber"
                        />
                      </div>
                      <div>
                        <Label htmlFor="field-label">Field Label</Label>
                        <Input
                          id="field-label"
                          value={newField.label}
                          onChange={(e) => setNewField({ ...newField, label: e.target.value })}
                          placeholder="e.g. Phone Number"
                        />
                      </div>
                      <div>
                        <Label htmlFor="field-type">Field Type</Label>
                        <Select
                          value={newField.type}
                          onValueChange={(value) => setNewField({ ...newField, type: value })}
                        >
                          <SelectTrigger id="field-type">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="text">Text</SelectItem>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="number">Number</SelectItem>
                            <SelectItem value="tel">Telephone</SelectItem>
                            <SelectItem value="select">Select</SelectItem>
                            <SelectItem value="radio">Radio</SelectItem>
                            <SelectItem value="file">File</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="field-required"
                          checked={newField.required}
                          onCheckedChange={(checked) => setNewField({ ...newField, required: checked })}
                        />
                        <Label htmlFor="field-required">Required</Label>
                      </div>
                      <Button onClick={handleAddField} className="ml-auto">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Field
                      </Button>
                    </div>
                  </div>

                  <div className="border rounded-md">
                    <Table>
                      <TableHeader className="bg-gray-50">
                        <TableRow>
                          <TableHead>Field ID</TableHead>
                          <TableHead>Label</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Required</TableHead>
                          <TableHead>Enabled</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {formFields.map((field) => (
                          <TableRow key={field.id}>
                            <TableCell>{field.id}</TableCell>
                            <TableCell>{field.label}</TableCell>
                            <TableCell>{field.type}</TableCell>
                            <TableCell>
                              <Checkbox
                                checked={field.required}
                                onCheckedChange={() => handleToggleRequired(field.id)}
                                disabled={["name", "email", "phone"].includes(field.id)}
                              />
                            </TableCell>
                            <TableCell>
                              <Switch
                                checked={field.enabled}
                                onCheckedChange={() => handleToggleField(field.id)}
                                disabled={["name", "email", "phone"].includes(field.id)}
                              />
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-red-500"
                                onClick={() => handleRemoveField(field.id)}
                                disabled={["name", "email", "phone"].includes(field.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="home-content">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Home Page Content</CardTitle>
                    <CardDescription>Customize the content displayed on the home page</CardDescription>
                  </div>
                  {!isEditingHomeContent ? (
                    <Button
                      onClick={() => setIsEditingHomeContent(true)}
                      className="bg-[#F2B705] hover:bg-[#e6a800] text-[#002147]"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Content
                    </Button>
                  ) : (
                    <Button onClick={handleSaveHomeContent} className="bg-green-600 hover:bg-green-700 text-white">
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="home-title">Page Title</Label>
                      <Input
                        id="home-title"
                        value={homeContent.title}
                        onChange={(e) => setHomeContent({ ...homeContent, title: e.target.value })}
                        placeholder="Enter page title"
                        disabled={!isEditingHomeContent}
                      />
                    </div>

                    <div>
                      <Label htmlFor="home-subtitle">Subtitle</Label>
                      <Input
                        id="home-subtitle"
                        value={homeContent.subtitle}
                        onChange={(e) => setHomeContent({ ...homeContent, subtitle: e.target.value })}
                        placeholder="Enter subtitle text"
                        disabled={!isEditingHomeContent}
                      />
                    </div>

                    <div>
                      <Label htmlFor="home-announcement">Announcement (Optional)</Label>
                      <Textarea
                        id="home-announcement"
                        value={homeContent.announcement}
                        onChange={(e) => setHomeContent({ ...homeContent, announcement: e.target.value })}
                        placeholder="Enter an announcement to display on the home page (leave empty for no announcement)"
                        disabled={!isEditingHomeContent}
                        className="min-h-[100px]"
                      />
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Preview</h3>
                    <div className="bg-white p-6 rounded border">
                      <h1 className="text-2xl font-bold text-[#002147] mb-2">{homeContent.title}</h1>
                      <p className="text-gray-600 mb-4">{homeContent.subtitle}</p>

                      {homeContent.announcement && (
                        <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded-r">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <svg
                                className="h-5 w-5 text-yellow-400"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 20 20"
                                fill="currentColor"
                              >
                                <path
                                  fillRule="evenodd"
                                  d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                                  clipRule="evenodd"
                                />
                              </svg>
                            </div>
                            <div className="ml-3">
                              <p className="text-sm text-yellow-700">{homeContent.announcement}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Registration Details Dialog */}
      <Dialog open={showRegistrationDetails} onOpenChange={setShowRegistrationDetails}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Registration Details</DialogTitle>
            <DialogDescription>
              Submitted on {selectedRegistration ? formatDate(selectedRegistration.timestamp) : ""}
            </DialogDescription>
          </DialogHeader>

          {selectedRegistration && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1 flex flex-col items-center">
                <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-[#F2B705] mb-4">
                  {selectedRegistration.profilePhotoUrl ? (
                    <img
                      src={selectedRegistration.profilePhotoUrl || "/placeholder.svg"}
                      alt={selectedRegistration.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#002147] flex items-center justify-center text-white text-4xl">
                      {selectedRegistration.name.charAt(0)}
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-bold">{selectedRegistration.name}</h3>
                <p className="text-gray-500 mb-2">{selectedRegistration.city}</p>

                <div className="mb-4 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-sm font-medium">
                  {selectedRegistration.playerRole === "Batsman" && "🏏 "}
                  {selectedRegistration.playerRole === "Bowler" && "🎯 "}
                  {selectedRegistration.playerRole === "All-Rounder" && "⭐ "}
                  {selectedRegistration.playerRole === "Wicket Keeper" && "🧤 "}
                  {selectedRegistration.playerRole}
                </div>
              </div>

              <div className="md:col-span-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Father's Name</p>
                    <p className="font-medium">{selectedRegistration.fatherName}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Age</p>
                    <p className="font-medium">{selectedRegistration.age} years</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{selectedRegistration.email}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Phone</p>
                    <p className="font-medium">+91 {selectedRegistration.phone}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Jersey Size</p>
                    <p className="font-medium">{selectedRegistration.jerseySize}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">City</p>
                    <p className="font-medium">{selectedRegistration.city}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Batting Style</p>
                    <p className="font-medium">{selectedRegistration.battingStyle}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Bowling Style</p>
                    <p className="font-medium">{selectedRegistration.bowlingStyle}</p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t">
                  <h4 className="font-medium mb-2">Registration Information</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Registration ID</p>
                      <p className="font-medium">#{selectedRegistration.id}</p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Registration Date</p>
                      <p className="font-medium">{formatDate(selectedRegistration.timestamp)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRegistrationDetails(false)}>
              Close
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (selectedRegistration) {
                  handleDeleteRegistration(selectedRegistration.id)
                  setShowRegistrationDetails(false)
                }
              }}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Registration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
