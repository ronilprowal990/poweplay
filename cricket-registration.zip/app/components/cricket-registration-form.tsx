"use client"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Upload, X } from "lucide-react"
import { addRegistration } from "@/lib/sync-service"

export default function RegistrationForm() {
  const router = useRouter()
  const fileInputRef = useRef(null)
  const [formData, setFormData] = useState({
    name: "",
    fatherName: "",
    age: "",
    email: "",
    phone: "",
    city: "",
    jerseySize: "",
    playerRole: "",
    battingStyle: "",
    bowlingStyle: "",
    termsAccepted: false,
  })
  const [profilePhoto, setProfilePhoto] = useState(null)
  const [profilePhotoPreview, setProfilePhotoPreview] = useState(null)
  const [showConfetti, setShowConfetti] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [currentStep, setCurrentStep] = useState(1)
  const [formAnimation, setFormAnimation] = useState("fadeIn")

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleProfilePhotoChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setProfilePhoto(file)

      // Create a preview URL
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfilePhotoPreview(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemovePhoto = () => {
    setProfilePhoto(null)
    setProfilePhotoPreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleTermsChange = (checked) => {
    setFormData((prev) => ({ ...prev, termsAccepted: checked }))
  }

  const nextStep = () => {
    setFormAnimation("fadeOut")
    setTimeout(() => {
      setCurrentStep(currentStep + 1)
      setFormAnimation("fadeIn")
    }, 300)
  }

  const prevStep = () => {
    setFormAnimation("fadeOut")
    setTimeout(() => {
      setCurrentStep(currentStep - 1)
      setFormAnimation("fadeIn")
    }, 300)
  }

  const validateStep = (step) => {
    switch (step) {
      case 1:
        return formData.name && formData.fatherName && formData.age && formData.email && formData.phone
      case 2:
        return formData.city && formData.jerseySize && formData.playerRole
      case 3:
        return formData.battingStyle && formData.bowlingStyle
      default:
        return true
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Security check simulation
    const now = Date.now()
    const formSubmitTime = Number.parseInt(sessionStorage.getItem("lastFormSubmit") || "0")

    // Rate limiting - prevent multiple submissions within 5 seconds
    if (now - formSubmitTime < 5000) {
      setError("Please wait before submitting again.")
      setIsSubmitting(false)
      return
    }

    sessionStorage.setItem("lastFormSubmit", now.toString())

    // Store player role in session storage for success page
    if (formData.playerRole) {
      sessionStorage.setItem("playerRole", formData.playerRole)
    }

    // Simulate form submission
    try {
      // In a real app, you would send this data to your API
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Create registration data
      const registrationData = {
        id: Math.floor(Math.random() * 10000),
        ...formData,
        profilePhotoUrl: profilePhotoPreview, // Include the photo data URL
        timestamp: new Date().toISOString(),
      }

      // Use our sync service to add the registration
      addRegistration(registrationData)

      // Show confetti animation
      setShowConfetti(true)

      // Play celebration sound
      try {
        const audio = new Audio("/success-sound.mp3")
        audio.volume = 0.5
        audio.play().catch((err) => console.log("Audio playback prevented:", err))
      } catch (err) {
        console.log("Audio playback error:", err)
      }

      // Redirect to success page after a delay
      setTimeout(() => {
        router.push("/success")
      }, 3000)
    } catch (error) {
      console.error("Registration failed:", error)
      setIsSubmitting(false)
      setError("Registration failed. Please try again.")
    }
  }

  // Step indicators
  const steps = [
    { number: 1, title: "Personal Info" },
    { number: 2, title: "Player Details" },
    { number: 3, title: "Playing Style" },
    { number: 4, title: "Review & Submit" },
  ]

  return (
    <>
      <motion.form
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: formAnimation === "fadeIn" ? 1 : 0, y: formAnimation === "fadeIn" ? 0 : 20 }}
        transition={{ duration: 0.3 }}
        onSubmit={handleSubmit}
        className="space-y-6"
      >
        <input type="hidden" name="_csrf" value={`${Math.random().toString(36).substring(2)}_${Date.now()}`} />
        {error && (
          <div className="p-3 mb-4 bg-red-50 border border-red-200 rounded-md flex items-center text-red-600 text-sm">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-2"
            >
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
            {error}
          </div>
        )}
        <h2 className="text-2xl font-bold text-center mb-6 text-[#002147]">Player Registration</h2>

        {/* Step indicators */}
        <div className="flex justify-between mb-8">
          {steps.map((step) => (
            <div key={step.number} className="flex flex-col items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  currentStep === step.number
                    ? "bg-[#F2B705] text-[#002147]"
                    : currentStep > step.number
                      ? "bg-green-500 text-white"
                      : "bg-gray-200 text-gray-500"
                }`}
              >
                {currentStep > step.number ? (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                ) : (
                  step.number
                )}
              </div>
              <span
                className={`text-xs mt-1 ${
                  currentStep === step.number ? "text-[#002147] font-medium" : "text-gray-500"
                }`}
              >
                {step.title}
              </span>
            </div>
          ))}
        </div>

        {/* Step 1: Personal Information */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="flex justify-center mb-6">
              <div className="flex flex-col items-center">
                <div className="relative mb-3">
                  {profilePhotoPreview ? (
                    <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-[#F2B705]">
                      <img
                        src={profilePhotoPreview || "/placeholder.svg"}
                        alt="Profile Preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={handleRemovePhoto}
                        className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1"
                        aria-label="Remove photo"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center border-4 border-[#F2B705] text-gray-400">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="48"
                        height="48"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                      </svg>
                    </div>
                  )}
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photo
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleProfilePhotoChange}
                  className="hidden"
                  aria-label="Upload profile photo"
                />
                <p className="text-xs text-gray-500 mt-1">JPG, PNG or GIF (Max 5MB)</p>
              </div>
            </div>

            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your full name"
                required
              />
            </div>

            <div>
              <Label htmlFor="fatherName">Father's Name</Label>
              <Input
                id="fatherName"
                name="fatherName"
                value={formData.fatherName}
                onChange={handleChange}
                placeholder="Enter your father's name"
                required
              />
            </div>

            <div>
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                name="age"
                type="number"
                value={formData.age}
                onChange={handleChange}
                placeholder="Enter your age"
                min="8"
                max="60"
                required
              />
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="your.email@example.com"
                required
              />
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <div className="flex">
                <span className="inline-flex items-center px-3 bg-muted border border-r-0 border-input rounded-l-md">
                  +91
                </span>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  className="rounded-l-none"
                  placeholder="9876543210"
                  pattern="[0-9]{10}"
                  required
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <Button
                type="button"
                onClick={nextStep}
                disabled={!validateStep(1)}
                className="bg-[#F2B705] hover:bg-[#e6a800] text-[#002147] font-bold"
              >
                Next
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="ml-2"
                >
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Player Details */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div>
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                name="city"
                value={formData.city || ""}
                onChange={handleChange}
                placeholder="Enter your city"
                required
              />
            </div>

            <div>
              <Label htmlFor="jerseySize">Jersey Size</Label>
              <Select
                name="jerseySize"
                value={formData.jerseySize}
                onValueChange={(value) => handleSelectChange("jerseySize", value)}
                required
              >
                <SelectTrigger id="jerseySize">
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="S">S</SelectItem>
                  <SelectItem value="M">M</SelectItem>
                  <SelectItem value="L">L</SelectItem>
                  <SelectItem value="XL">XL</SelectItem>
                  <SelectItem value="XXL">XXL</SelectItem>
                  <SelectItem value="XXXL">XXXL</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="playerRole">Player Role</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                {[
                  { value: "batsman", label: "Batsman", icon: "🏏" },
                  { value: "bowler", label: "Bowler", icon: "🎯" },
                  { value: "all-rounder", label: "All-Rounder", icon: "⭐" },
                  { value: "wicket-keeper", label: "Wicket Keeper", icon: "🧤" },
                ].map((role) => (
                  <motion.div
                    key={role.value}
                    className={`relative rounded-lg border-2 p-3 cursor-pointer transition-all ${
                      formData.playerRole === role.value
                        ? "border-[#F2B705] bg-[#F2B705]/10"
                        : "border-gray-200 hover:border-[#F2B705]/50"
                    }`}
                    onClick={() => handleSelectChange("playerRole", role.value)}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-1">{role.icon}</div>
                      <div className="text-sm font-medium">{role.label}</div>
                    </div>
                    {formData.playerRole === role.value && (
                      <motion.div
                        className="absolute -top-2 -right-2 bg-[#F2B705] text-[#002147] rounded-full w-6 h-6 flex items-center justify-center"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="14"
                          height="14"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </motion.div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="pt-4 flex justify-between">
              <Button type="button" onClick={prevStep} variant="outline" className="text-[#002147]">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-2"
                >
                  <line x1="19" y1="12" x2="5" y2="12"></line>
                  <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back
              </Button>
              <Button
                type="button"
                onClick={nextStep}
                disabled={!validateStep(2)}
                className="bg-[#F2B705] hover:bg-[#e6a800] text-[#002147] font-bold"
              >
                Next
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="ml-2"
                >
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Playing Style */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Batting Style</Label>
                <RadioGroup
                  value={formData.battingStyle}
                  onValueChange={(value) => handleSelectChange("battingStyle", value)}
                  className="flex space-x-4 mt-2"
                  required
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="right-handed" id="batting-right-handed" />
                    <Label htmlFor="batting-right-handed" className="cursor-pointer">
                      Right Handed
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="left-handed" id="batting-left-handed" />
                    <Label htmlFor="batting-left-handed" className="cursor-pointer">
                      Left Handed
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>Bowling Style</Label>
                <RadioGroup
                  value={formData.bowlingStyle}
                  onValueChange={(value) => handleSelectChange("bowlingStyle", value)}
                  className="flex space-x-4 mt-2"
                  required
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="right-handed" id="bowling-right-handed" />
                    <Label htmlFor="bowling-right-handed" className="cursor-pointer">
                      Right Handed
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="left-handed" id="bowling-left-handed" />
                    <Label htmlFor="bowling-left-handed" className="cursor-pointer">
                      Left Handed
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
            <div className="pt-4 flex justify-between">
              <Button type="button" onClick={prevStep} variant="outline" className="text-[#002147]">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-2"
                >
                  <line x1="19" y1="12" x2="5" y2="12"></line>
                  <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back
              </Button>
              <Button
                type="button"
                onClick={nextStep}
                disabled={!validateStep(3)}
                className="bg-[#F2B705] hover:bg-[#e6a800] text-[#002147] font-bold"
              >
                Next
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="ml-2"
                >
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              </Button>
            </div>
          </div>
        )}

        {/* Step 4: Review & Submit */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <div className="bg-[#002147]/5 p-4 rounded-lg mb-6">
              <h3 className="font-medium text-[#002147] mb-2">Review Your Information</h3>
              <p className="text-sm text-gray-600">
                Please review your registration details before submitting. You can go back to make changes if needed.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-[#002147] mb-3">Personal Information</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Full Name:</span>
                    <span className="text-sm font-medium">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Father's Name:</span>
                    <span className="text-sm font-medium">{formData.fatherName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Age:</span>
                    <span className="text-sm font-medium">{formData.age}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Email:</span>
                    <span className="text-sm font-medium">{formData.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Phone:</span>
                    <span className="text-sm font-medium">+91 {formData.phone}</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-[#002147] mb-3">Player Details</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">City:</span>
                    <span className="text-sm font-medium">{formData.city}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Jersey Size:</span>
                    <span className="text-sm font-medium">{formData.jerseySize}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Player Role:</span>
                    <span className="text-sm font-medium">
                      {formData.playerRole === "batsman" && "🏏 "}
                      {formData.playerRole === "bowler" && "🎯 "}
                      {formData.playerRole === "all-rounder" && "⭐ "}
                      {formData.playerRole === "wicket-keeper" && "🧤 "}
                      {formData.playerRole.charAt(0).toUpperCase() + formData.playerRole.slice(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Batting Style:</span>
                    <span className="text-sm font-medium">{formData.battingStyle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Bowling Style:</span>
                    <span className="text-sm font-medium">{formData.bowlingStyle}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-center mt-6">
              <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-[#F2B705]">
                {profilePhotoPreview ? (
                  <img
                    src={profilePhotoPreview || "/placeholder.svg"}
                    alt="Profile Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="32"
                      height="32"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                      <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-8 border-t pt-6">
              <div className="bg-[#002147]/5 p-4 rounded-lg mb-4">
                <h3 className="font-medium text-[#002147] mb-2">Terms and Conditions</h3>
                <div className="text-sm text-gray-600 max-h-32 overflow-y-auto mb-4 p-2 bg-white/50 rounded border">
                  <p className="mb-2">
                    By registering for the PowerPlay Champions Trophy, you agree to the following terms:
                  </p>
                  <ol className="list-decimal pl-5 space-y-1">
                    <li>All players must adhere to the tournament rules and regulations.</li>
                    <li>Players must arrive at least 20 minutes before their scheduled match time.</li>
                    <li className="font-bold text-red-600">
                      Registration fees are non-refundable once a player is registered.
                    </li>
                    <li className="font-bold text-red-600">
                      The decision of the umpires and tournament officials will be final.
                    </li>
                  </ol>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="terms"
                    checked={formData.termsAccepted}
                    onCheckedChange={handleTermsChange}
                    className="mt-1"
                  />
                  <Label htmlFor="terms" className="text-sm cursor-pointer">
                    I agree to the terms and conditions, including the non-refundable registration fee policy
                  </Label>
                </div>
                {formData.termsAccepted === false && (
                  <p className="text-red-500 text-xs mt-2">* You must accept the terms and conditions to proceed</p>
                )}
              </div>
            </div>

            <div className="pt-4 flex justify-between">
              <Button type="button" onClick={prevStep} variant="outline" className="text-[#002147]">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-2"
                >
                  <line x1="19" y1="12" x2="5" y2="12"></line>
                  <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back
              </Button>
              <Button
                type="submit"
                className="bg-[#F2B705] hover:bg-[#e6a800] text-[#002147] font-bold"
                disabled={isSubmitting || !formData.termsAccepted}
              >
                {isSubmitting ? (
                  <>
                    <svg
                      className="animate-spin -ml-1 mr-2 h-4 w-4 text-[#002147]"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Registering...
                  </>
                ) : (
                  <>
                    Submit Registration
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="ml-2"
                    >
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </motion.form>
    </>
  )
}
