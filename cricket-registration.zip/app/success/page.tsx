"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Confetti } from "@/components/confetti"
import { ArrowLeft, Instagram } from "lucide-react"

export default function SuccessPage() {
  const [playerRole, setPlayerRole] = useState("")

  useEffect(() => {
    // Get player role from session storage if available
    const storedRole = sessionStorage.getItem("playerRole") || ""
    setPlayerRole(storedRole)

    // Play celebration sound
    try {
      const audio = new Audio("/success-sound.mp3")
      audio.volume = 0.5
      audio.play().catch((err) => console.log("Audio playback prevented:", err))
    } catch (err) {
      console.log("Audio playback error:", err)
    }
  }, [])

  // Role-specific messages
  const getRoleMessage = () => {
    switch (playerRole) {
      case "batsman":
        return "Get ready to showcase your batting skills on the pitch!"
      case "bowler":
        return "Prepare to take wickets and dominate with your bowling!"
      case "all-rounder":
        return "Your versatile skills will be a great asset to any team!"
      case "wicket-keeper":
        return "Your quick reflexes behind the stumps will be crucial!"
      default:
        return "We're excited to see your cricket skills in action!"
    }
  }

  // Role-specific icons
  const getRoleIcon = () => {
    switch (playerRole) {
      case "batsman":
        return "🏏"
      case "bowler":
        return "🎯"
      case "all-rounder":
        return "⭐"
      case "wicket-keeper":
        return "🧤"
      default:
        return "🏆"
    }
  }

  return (
    <div className="min-h-screen cricket-bg flex items-center justify-center p-4">
      <Confetti />

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full bg-white rounded-xl shadow-2xl p-8 text-center"
      >
        <div className="mb-6 flex justify-center">
          <div className="relative w-32 h-32">
            <Image src="/images/powerplay-logo.png" alt="PowerPlay Champions Trophy" fill className="object-contain" />
          </div>
        </div>

        <h1 className="text-2xl font-bold mb-2 text-[#002147]">Registration Successful!</h1>

        <div className="my-4 p-3 bg-[#F2B705]/20 rounded-lg inline-block">
          <span className="text-3xl">{getRoleIcon()}</span>
        </div>

        <p className="text-gray-600 mb-2">
          Congratulations! You have successfully registered for the PowerPlay Champions Trophy.
        </p>

        <p className="text-[#002147] font-medium mb-6">{getRoleMessage()}</p>

        <div className="p-4 bg-gray-50 rounded-lg mb-6 text-left">
          <h3 className="font-bold text-sm text-gray-700 mb-2">Next Steps:</h3>
          <ul className="text-sm text-gray-600 space-y-1">
            <li className="flex items-start">
              <span className="mr-2 text-[#F2B705]">✓</span>
              Check your email for confirmation details
            </li>
            <li className="flex items-start">
              <span className="mr-2 text-[#F2B705]">✓</span>
              Join our WhatsApp group for updates
            </li>
            <li className="flex items-start">
              <span className="mr-2 text-[#F2B705]">✓</span>
              Follow us on Instagram for tournament news
            </li>
          </ul>
        </div>

        <div className="space-y-3">
          <Button asChild className="w-full bg-[#F2B705] hover:bg-[#e6a800] text-[#002147] font-bold">
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Return to Home
            </Link>
          </Button>

          <a
            href="https://www.instagram.com/powerplaychampionstrophy?igsh=NmllZXkwanNwamdp"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center w-full px-4 py-2 mt-2 rounded-md bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:from-purple-700 hover:to-pink-600 transition-all"
          >
            <Instagram className="h-4 w-4 mr-2" />
            Follow for more updates
          </a>
        </div>
      </motion.div>
    </div>
  )
}
