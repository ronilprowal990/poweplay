"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"

export default function CricketBackground() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    let animationFrameId

    // Set canvas dimensions
    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    handleResize()

    // Cricket ball animation
    const balls = []
    for (let i = 0; i < 15; i++) {
      balls.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: 5 + Math.random() * 10,
        dx: (Math.random() - 0.5) * 2,
        dy: (Math.random() - 0.5) * 2,
        color: `rgba(200, 30, 30, ${0.1 + Math.random() * 0.2})`,
      })
    }

    // Cricket bat silhouettes
    const bats = []
    for (let i = 0; i < 5; i++) {
      bats.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        rotation: Math.random() * Math.PI * 2,
        scale: 0.5 + Math.random() * 0.5,
        opacity: 0.05 + Math.random() * 0.1,
      })
    }

    const drawBall = (ball) => {
      ctx.beginPath()
      ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2)
      ctx.fillStyle = ball.color
      ctx.fill()

      // Add seam
      ctx.beginPath()
      ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(255, 255, 255, 0.3)"
      ctx.lineWidth = 1
      ctx.stroke()
    }

    const drawBat = (bat) => {
      ctx.save()
      ctx.translate(bat.x, bat.y)
      ctx.rotate(bat.rotation)
      ctx.scale(bat.scale, bat.scale)

      // Draw bat handle
      ctx.beginPath()
      ctx.rect(-5, -80, 10, 60)
      ctx.fillStyle = `rgba(242, 183, 5, ${bat.opacity})`
      ctx.fill()

      // Draw bat blade
      ctx.beginPath()
      ctx.rect(-20, -20, 40, 100)
      ctx.fillStyle = `rgba(242, 183, 5, ${bat.opacity})`
      ctx.fill()

      ctx.restore()
    }

    // Add this function inside the useEffect
    const drawPlayerRoleElements = () => {
      // Draw cricket elements based on different player roles

      // Batsman elements - cricket bats
      for (let i = 0; i < 3; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        const size = 30 + Math.random() * 20

        ctx.save()
        ctx.translate(x, y)
        ctx.rotate(Math.random() * Math.PI * 2)
        ctx.globalAlpha = 0.05

        // Draw bat handle
        ctx.beginPath()
        ctx.rect(-size / 10, -size, size / 5, size * 0.6)
        ctx.fillStyle = "#F2B705"
        ctx.fill()

        // Draw bat blade
        ctx.beginPath()
        ctx.rect(-size / 2, -size * 0.4, size, size)
        ctx.fillStyle = "#F2B705"
        ctx.fill()

        ctx.restore()
      }

      // Bowler elements - cricket balls
      for (let i = 0; i < 5; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        const size = 10 + Math.random() * 15

        ctx.beginPath()
        ctx.arc(x, y, size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(200, 30, 30, 0.05)`
        ctx.fill()

        // Add seam
        ctx.beginPath()
        ctx.arc(x, y, size, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(255, 255, 255, 0.1)"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Wicket keeper elements - stumps and gloves
      for (let i = 0; i < 2; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height

        // Draw stumps
        ctx.save()
        ctx.translate(x, y)
        ctx.globalAlpha = 0.05

        for (let j = 0; j < 3; j++) {
          ctx.beginPath()
          ctx.rect(j * 10 - 10, -30, 5, 60)
          ctx.fillStyle = "#F5E6CA"
          ctx.fill()
        }

        // Draw bails
        ctx.beginPath()
        ctx.rect(-10, -32, 25, 3)
        ctx.fillStyle = "#F5E6CA"
        ctx.fill()

        ctx.restore()
      }
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw navy blue background
      ctx.fillStyle = "#002147"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw subtle pattern
      for (let i = 0; i < 50; i++) {
        ctx.beginPath()
        ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, Math.random() * 2, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(245, 230, 202, 0.1)"
        ctx.fill()
      }

      // Draw bats
      bats.forEach(drawBat)

      // Update and draw balls
      balls.forEach((ball) => {
        ball.x += ball.dx
        ball.y += ball.dy

        // Bounce off walls
        if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) {
          ball.dx = -ball.dx
        }

        if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) {
          ball.dy = -ball.dy
        }

        drawBall(ball)
      })

      drawPlayerRoleElements()
      animationFrameId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", handleResize)
      cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return (
    <>
      <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full z-0" />
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-[#001a38]/40 to-[#002147]/60 z-1" />

      {/* Animated cricket elements */}
      <motion.div
        className="absolute z-1 opacity-10"
        animate={{
          x: ["0%", "100%", "0%"],
          y: ["0%", "100%", "0%"],
        }}
        transition={{
          duration: 20,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
        style={{ top: "10%", left: "10%" }}
      >
        <div className="w-32 h-32 rounded-full border-4 border-[#F2B705]" />
      </motion.div>

      <motion.div
        className="absolute z-1 opacity-10"
        animate={{
          x: ["100%", "0%", "100%"],
          y: ["100%", "0%", "100%"],
        }}
        transition={{
          duration: 25,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
        style={{ bottom: "20%", right: "15%" }}
      >
        <div className="w-40 h-40 rounded-full border-4 border-[#F2B705]" />
      </motion.div>
    </>
  )
}
