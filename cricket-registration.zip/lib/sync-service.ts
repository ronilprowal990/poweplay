// Enhanced real-time sync service using localStorage and polling
// In a production app, you would use WebSockets or a real-time database like Firebase

// Event types for our sync system
export type SyncEventType = "REGISTRATION_STATUS_CHANGE" | "NEW_REGISTRATION" | "HOME_CONTENT_UPDATE" | "ADMIN_ACTION"

// Event data structure
export interface SyncEvent {
  type: SyncEventType
  data: any
  timestamp: number
  deviceId: string // To identify which device sent the event
}

// Store for last processed event timestamp
const LAST_EVENT_KEY = "cricket_last_event_timestamp"
const EVENTS_KEY = "cricket_sync_events"
const DEVICE_ID_KEY = "cricket_device_id"

// Generate a unique device ID if not exists
function getDeviceId(): string {
  let deviceId = localStorage.getItem(DEVICE_ID_KEY)
  if (!deviceId) {
    deviceId = `device_${Math.random().toString(36).substring(2, 9)}_${Date.now()}`
    localStorage.setItem(DEVICE_ID_KEY, deviceId)
  }
  return deviceId
}

// Initialize the sync service
export function initSyncService() {
  // Set up initial timestamp if not exists
  if (!localStorage.getItem(LAST_EVENT_KEY)) {
    localStorage.setItem(LAST_EVENT_KEY, Date.now().toString())
  }

  // Initialize events array if not exists
  if (!localStorage.getItem(EVENTS_KEY)) {
    localStorage.setItem(EVENTS_KEY, JSON.stringify([]))
  }

  // Generate device ID if not exists
  getDeviceId()

  console.log("Sync service initialized with device ID:", getDeviceId())
}

// Publish an event to all devices
export function publishEvent(type: SyncEventType, data: any) {
  const event: SyncEvent = {
    type,
    data,
    timestamp: Date.now(),
    deviceId: getDeviceId(),
  }

  try {
    // Get current events
    const eventsJson = localStorage.getItem(EVENTS_KEY) || "[]"
    const events: SyncEvent[] = JSON.parse(eventsJson)

    // Add new event
    events.push(event)

    // Keep only last 100 events to prevent localStorage from getting too large
    const trimmedEvents = events.slice(-100)

    // Save back to localStorage
    localStorage.setItem(EVENTS_KEY, JSON.stringify(trimmedEvents))

    // Reset the last event timestamp to ensure all clients receive this event
    // This forces all devices to process this event even if they just checked for events
    localStorage.setItem(LAST_EVENT_KEY, (event.timestamp - 2000).toString())

    console.log(`Published event: ${type}`, data)
    return true
  } catch (error) {
    console.error("Failed to publish event:", error)
    return false
  }
}

// Subscribe to events with a callback
export function subscribeToEvents(callback: (events: SyncEvent[]) => void, pollInterval = 1000) {
  // Initialize the service
  initSyncService()

  const deviceId = getDeviceId()

  // Function to check for new events
  const checkForEvents = () => {
    try {
      // Get last processed timestamp
      const lastTimestamp = Number.parseInt(localStorage.getItem(LAST_EVENT_KEY) || "0")

      // Get all events
      const eventsJson = localStorage.getItem(EVENTS_KEY) || "[]"
      const events: SyncEvent[] = JSON.parse(eventsJson)

      // Filter events newer than last processed and not from this device
      const newEvents = events.filter((event) => event.timestamp > lastTimestamp)

      if (newEvents.length > 0) {
        // Update last processed timestamp
        const latestTimestamp = Math.max(...newEvents.map((e) => e.timestamp))
        localStorage.setItem(LAST_EVENT_KEY, latestTimestamp.toString())

        // Call the callback with new events
        callback(newEvents)

        // Log events from other devices
        const externalEvents = newEvents.filter((event) => event.deviceId !== deviceId)
        if (externalEvents.length > 0) {
          console.log(`Received ${externalEvents.length} events from other devices:`, externalEvents)
        }
      }
    } catch (error) {
      console.error("Error checking for events:", error)
    }
  }

  // Immediately check for events on subscribe
  checkForEvents()

  // Start polling with an initial immediate check
  const intervalId = setInterval(checkForEvents, pollInterval)

  // Return unsubscribe function
  return () => clearInterval(intervalId)
}

// Get the current registration status
export function getRegistrationStatus(): boolean {
  return JSON.parse(localStorage.getItem("registrationOpen") || "true")
}

// Get the home screen content
export interface HomeContent {
  title: string
  subtitle: string
  announcement: string
}

export function getHomeContent(): HomeContent {
  const defaultContent: HomeContent = {
    title: "PowerPlay Champions Trophy",
    subtitle: "Join the most exciting cricket tournament of the year! Register now to showcase your talent.",
    announcement: "",
  }

  try {
    const storedContent = localStorage.getItem("homeContent")
    return storedContent ? JSON.parse(storedContent) : defaultContent
  } catch (error) {
    return defaultContent
  }
}

// Update home content
export function updateHomeContent(content: HomeContent) {
  try {
    // Store the content in localStorage
    localStorage.setItem("homeContent", JSON.stringify(content))

    // Force a timestamp reset to ensure all clients receive this event
    const currentTime = Date.now()
    localStorage.setItem(LAST_EVENT_KEY, (currentTime - 2000).toString())

    // Publish the event with high priority
    const success = publishEvent("HOME_CONTENT_UPDATE", content)

    // Log the result
    console.log(`Home content update published: ${success ? "success" : "failed"}`, content)

    return success
  } catch (error) {
    console.error("Failed to update home content:", error)
    return false
  }
}

// Update registration status
export function updateRegistrationStatus(isOpen: boolean) {
  localStorage.setItem("registrationOpen", JSON.stringify(isOpen))
  publishEvent("REGISTRATION_STATUS_CHANGE", { isOpen })
}

// Add new registration
export function addRegistration(registrationData: any) {
  // Get existing registrations
  const existingData = JSON.parse(localStorage.getItem("registrations") || "[]")

  // Add new registration
  existingData.push(registrationData)

  // Save back to localStorage
  localStorage.setItem("registrations", JSON.stringify(existingData))

  // Publish event with high priority to ensure all admins get notified
  publishEvent("NEW_REGISTRATION", registrationData)
}

// Get all registrations
export function getRegistrations() {
  return JSON.parse(localStorage.getItem("registrations") || "[]")
}

// Delete a registration
export function deleteRegistration(id: number) {
  const registrations = getRegistrations()
  const updatedRegistrations = registrations.filter((reg) => reg.id !== id)
  localStorage.setItem("registrations", JSON.stringify(updatedRegistrations))
  publishEvent("ADMIN_ACTION", { action: "DELETE_REGISTRATION", id })
}
