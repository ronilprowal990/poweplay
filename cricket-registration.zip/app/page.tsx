"use client"

import Link from "next/link"
import Image from "next/image"
import RegistrationForm from "@/components/registration-form"
import CricketBackground from "@/components/cricket-background"
import { motion } from "framer-motion"
import { ChevronDown, Instagram, AlertCircle } from "lucide-react"
import { useState, useEffect } from "react"
import { getRegistrationStatus, subscribeToEvents, getHomeContent, type HomeContent } from "@/lib/sync-service"

export default function Home() {
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(true)
  const [homeContent, setHomeContent] = useState<HomeContent>({
    title: "PowerPlay Champions Trophy",
    subtitle: "Join the most exciting cricket tournament of the year! Register now to showcase your talent.",
    announcement: "",
  })
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    // Initial state
    setIsRegistrationOpen(getRegistrationStatus())
    setHomeContent(getHomeContent())
    setIsInitialized(true)

    // Subscribe to real-time updates with a faster polling interval for better responsiveness
    const unsubscribe = subscribeToEvents((events) => {
      events.forEach((event) => {
        if (event.type === "REGISTRATION_STATUS_CHANGE") {
          console.log("Registration status changed:", event.data.isOpen)
          setIsRegistrationOpen(event.data.isOpen)

          // Play notification sound for status change
          try {
            const audio = new Audio("/notification-sound.mp3")
            audio.volume = 0.3
            audio.play().catch((err) => console.log("Audio playback prevented:", err))
          } catch (err) {
            console.log("Audio playback error:", err)
          }
        } else if (event.type === "HOME_CONTENT_UPDATE") {
          console.log("Home content updated:", event.data)

          // Ensure we're updating with the complete content object
          if (event.data && typeof event.data === "object") {
            // Force a re-render by creating a new object
            setHomeContent({ ...event.data })

            // Log the update for debugging
            console.log("Updated home content state:", event.data)
          }
        }
      })
    }, 200) // Poll every 200ms for more responsive updates

    // Cleanup subscription
    return () => unsubscribe()
  }, [])

  // Don't render until we've initialized
  if (!isInitialized) {
    return (
      <div className="min-h-screen cricket-bg flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#F2B705]"></div>
      </div>
    )
  }

  return (
    <main className="min-h-screen relative overflow-hidden cricket-bg">
      <CricketBackground />

      {/* Instagram Button - Top Right */}
      <motion.div
        className="absolute top-4 right-4 z-20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <a
          href="https://www.instagram.com/powerplaychampionstrophy?igsh=NmllZXkwanNwamdp"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:from-purple-700 hover:to-pink-600 transition-all shadow-lg"
        >
          <Instagram className="h-5 w-5 mr-2" />
          <span className="font-medium">Follow for updates</span>
        </a>
      </motion.div>

      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="text-center mb-8">
          <motion.div
            className="flex justify-center mb-6"
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, type: "spring" }}
          >
            <div className="relative w-64 h-64 md:w-80 md:h-80 logo-glow">
              <Image
                src="/images/powerplay-logo.png"
                alt="PowerPlay Champions Trophy"
                fill
                className="object-contain logo-shadow"
                priority
              />
            </div>
          </motion.div>

          <motion.h1
            className="text-3xl md:text-4xl font-bold cricket-cream drop-shadow-md mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            {homeContent.title}
          </motion.h1>

          <motion.p
            className="text-xl md:text-2xl cricket-cream drop-shadow-md max-w-3xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            {homeContent.subtitle}
          </motion.p>

          {homeContent.announcement && (
            <motion.div
              className="mt-6 bg-yellow-100 border-l-4 border-yellow-500 p-4 max-w-3xl mx-auto rounded-r-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">{homeContent.announcement}</p>
                </div>
              </div>
            </motion.div>
          )}
        </div>

        <motion.div
          className="flex justify-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.5 }}
        >
          <ChevronDown className="animate-bounce text-[#F5E6CA] w-8 h-8" />
        </motion.div>

        {isRegistrationOpen ? (
          <motion.div
            className="max-w-3xl mx-auto bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl p-6 md:p-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0, duration: 0.8 }}
            key="registration-form"
          >
            <RegistrationForm />
          </motion.div>
        ) : (
          <motion.div
            className="max-w-3xl mx-auto bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl p-6 md:p-8 text-center"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0, duration: 0.8 }}
            key="registration-closed"
          >
            <div className="py-10">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 1.2, duration: 0.5 }}
                className="text-red-500 mb-4"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="64"
                  height="64"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mx-auto"
                >
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="8" x2="12" y2="12"></line>
                  <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
              </motion.div>
              <h2 className="text-3xl font-bold text-[#002147] mb-4">Registration Closed</h2>
              <p className="text-lg text-gray-600 mb-6">
                Thank you for your interest in PowerPlay Champions Trophy! Registration is currently closed.
              </p>
              <p className="text-md text-gray-500 mb-8">
                Please follow us on Instagram for updates on when registration will reopen.
              </p>
              <a
                href="https://www.instagram.com/powerplaychampionstrophy?igsh=NmllZXkwanNwamdp"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:from-purple-700 hover:to-pink-600 transition-all shadow-lg"
              >
                <Instagram className="h-5 w-5 mr-2" />
                <span className="font-medium">Follow for updates</span>
              </a>
            </div>
          </motion.div>
        )}

        <div className="mt-8 text-center">
          <Link href="/admin" className="text-white/80 hover:text-white underline text-sm transition-colors">
            Admin Login
          </Link>
        </div>
      </div>
    </main>
  )
}
